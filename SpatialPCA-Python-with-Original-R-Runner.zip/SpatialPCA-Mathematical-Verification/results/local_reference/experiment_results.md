# Original R and Python comparison

Execution: local runtime
Upstream commit: 1d4dbb1fe6f23b77bb7ed805ce2de8bbc017ef66

Scope: synthetic full-rank model core with identical Y and K; no Seurat/SPARK preprocessing.

Correction: the official upstream objective includes log(S). The earlier missing-log claim is withdrawn. no_log_ablation is deliberately altered Python.

| Seed | Scale | R tau | Python tau | Relative tau gap | W angle (deg) | Relative WZ gap | Profile parity |
|---:|---:|---:|---:|---:|---:|---:|:---|
| 23 | 0.5 | 6.13530559 | 6.13530495 | 1.05e-07 | 7.15e-07 | 1.41e-08 | PASS |
| 23 | 1 | 6.13530539 | 6.1353052 | 3.18e-08 | 2.17e-07 | 4.28e-09 | PASS |
| 23 | 2 | 6.13530605 | 6.1353052 | 1.39e-07 | 9.51e-07 | 1.87e-08 | PASS |
| 41 | 0.5 | 3.5556273 | 3.55562701 | 8.19e-08 | 6.76e-07 | 2.18e-08 | PASS |
| 41 | 1 | 3.55562766 | 3.55562746 | 5.53e-08 | 4.56e-07 | 1.47e-08 | PASS |
| 41 | 2 | 3.55562728 | 3.55562727 | 2.99e-09 | 2.47e-08 | 7.97e-10 | PASS |
| 2026 | 0.5 | 9.73946847 | 9.73947012 | 1.7e-07 | 4.14e-07 | 3.17e-08 | PASS |
| 2026 | 1 | 9.73947128 | 9.73946945 | 1.88e-07 | 4.59e-07 | 3.5e-08 | PASS |
| 2026 | 2 | 9.73946809 | 9.73946979 | 1.74e-07 | 4.26e-07 | 3.26e-08 | PASS |

## Scale invariance

- Seed 23, R: max/min tau = 1.00000011.
- Seed 23, Python: max/min tau = 1.00000004.
- Seed 41, R: max/min tau = 1.0000001.
- Seed 41, Python: max/min tau = 1.00000013.
- Seed 2026, R: max/min tau = 1.00000033.
- Seed 2026, Python: max/min tau = 1.00000007.

## Failures

None.

Boundary solutions are explicitly flagged in the CSV/JSON and do not establish an unconstrained optimum.
No claim is made about real biological datasets or the full published pipeline.
