# Python model-core demonstration

Input data/demo_synthetic.npz is a seeded synthetic dataset with 12 genes and 16 spots. The model returns W, Z, tau, sigma2 and beta.

The earlier alternative called r_expression was mislabeled. It is now no_log_ablation, a deliberately altered objective, not the author's R code. Earlier numbers from that mode cannot establish an R bug.

For actual original-R execution and matched Python results, use local_reference/experiment_results.md. That experiment has 16 genes and 25 spots, three seeds and three scales.
